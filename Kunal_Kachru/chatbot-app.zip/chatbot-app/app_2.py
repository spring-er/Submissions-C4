import streamlit as st
import requests
import json
import os
import time
from datetime import datetime

# ======================================================
# CONFIG
# ======================================================
OPENROUTER_API_KEY = "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"
MODEL_NAME = "openai/gpt-oss-120b"

STORAGE_FILE = "storage/chats.json"

# ======================================================
# STORAGE SETUP
# ======================================================
os.makedirs("storage", exist_ok=True)

if not os.path.exists(STORAGE_FILE):
    with open(STORAGE_FILE, "w") as f:
        json.dump({}, f)


def load_chats():
    with open(STORAGE_FILE, "r") as f:
        return json.load(f)


def save_chats(chats):
    with open(STORAGE_FILE, "w") as f:
        json.dump(chats, f, indent=4)


# ======================================================
# OPENROUTER API CALL
# ======================================================
def get_ai_response(messages):
    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": MODEL_NAME,
        "messages": messages
    }

    res = requests.post(url, headers=headers, json=payload)

    if res.status_code != 200:
        return f"❌ API Error: {res.text}"

    return res.json()["choices"][0]["message"]["content"]


# ======================================================
# STREAMLIT PAGE SETUP
# ======================================================
st.set_page_config(page_title="Chatbot Assignment", page_icon="🤖", layout="wide")

# ======================================================
# SESSION TIMER
# ======================================================
if "start_time" not in st.session_state:
    st.session_state.start_time = time.time()

session_duration = int(time.time() - st.session_state.start_time)

# ======================================================
# LOAD CHATS
# ======================================================
chats = load_chats()

if len(chats) == 0:
    chats["Default Chat"] = []

chat_names = list(chats.keys())

# ======================================================
# SIDEBAR CONFIGURATION UI (MATCH SCREENSHOT)
# ======================================================
st.sidebar.title("⚙️ Configuration")

st.sidebar.markdown("### Assistant Settings")

assistant_name = st.sidebar.text_input(
    "Assistant Name:",
    value="This is a cool assistant!"
)

response_style = st.sidebar.selectbox(
    "Response Style:",
    ["Friendly", "Professional", "Funny", "Short"]
)

st.sidebar.markdown("### Chat Settings")

max_history = st.sidebar.slider(
    "Max Chat History:",
    5, 50, 40
)

show_timestamps = st.sidebar.checkbox("Show Timestamps", value=True)

st.sidebar.markdown("---")

# ======================================================
# CHAT SESSION MANAGER
# ======================================================
selected_chat = st.sidebar.selectbox("💬 Select Chat", chat_names)

col1, col2, col3 = st.sidebar.columns(3)

# Create new chat
if col1.button("➕"):
    new_name = f"Chat {len(chats)+1}"
    chats[new_name] = []
    save_chats(chats)
    st.rerun()

# Delete chat
if col2.button("🗑"):
    if selected_chat in chats:
        del chats[selected_chat]
        if len(chats) == 0:
            chats["Default Chat"] = []
        save_chats(chats)
        st.rerun()

# Clear chat
if col3.button("🧹"):
    chats[selected_chat] = []
    save_chats(chats)
    st.rerun()

# ======================================================
# SESSION STATS PANEL (MATCH SCREENSHOT)
# ======================================================
st.sidebar.markdown("---")
st.sidebar.subheader("📊 Session Stats")

messages_sent = len([m for m in chats[selected_chat] if m["role"] == "user"])
total_messages = len(chats[selected_chat])

st.sidebar.markdown("**Session Duration**")
st.sidebar.markdown(f"## {session_duration//60}m {session_duration%60}s")

st.sidebar.markdown("**Messages Sent**")
st.sidebar.markdown(f"## {messages_sent}")

st.sidebar.markdown("**Total Messages**")
st.sidebar.markdown(f"## {total_messages}")

# ======================================================
# EXPORT CHAT
# ======================================================
def export_chat():
    txt = ""
    for msg in chats[selected_chat]:
        txt += f"{msg['role'].upper()}: {msg['content']}\n\n"
    return txt


st.sidebar.download_button(
    "📥 Export Chat (.txt)",
    export_chat(),
    file_name=f"{selected_chat}.txt",
    mime="text/plain"
)

# ======================================================
# MAIN CHAT HEADER
# ======================================================
st.markdown(f"# 🚀 {assistant_name}")

st.caption(
    f"Response Style: **{response_style}** | History Limit: **{max_history} messages**"
)

# ======================================================
# OPTIONAL EXPANDERS (SCREENSHOT)
# ======================================================
with st.expander("ℹ️ About This Demo"):
    st.write("This is a ChatGPT-style chatbot built using Streamlit + OpenRouter API.")

with st.expander("📌 Instructor Notes"):
    st.write("Assignment Requirements: Chat UI, Sidebar Config, Local Storage, OpenRouter Model.")

dev_mode = st.checkbox("Show Development Info")

if dev_mode:
    st.info(f"Model: {MODEL_NAME}")
    st.info(f"Chat Stored Locally: {STORAGE_FILE}")

# ======================================================
# DISPLAY CHAT MESSAGES
# ======================================================
for msg in chats[selected_chat][-max_history:]:
    role = msg["role"]
    content = msg["content"]
    timestamp = msg.get("time", "")

    with st.chat_message(role):
        if show_timestamps and timestamp:
            st.markdown(f"🕒 *{timestamp}*")
        st.markdown(content)

# ======================================================
# USER INPUT
# ======================================================
user_input = st.chat_input(f"Message {assistant_name}...")

if user_input:
    now = datetime.now().strftime("%H:%M:%S")

    # Add user message
    chats[selected_chat].append({
        "role": "user",
        "content": user_input,
        "time": now
    })

    # Limit stored history
    chats[selected_chat] = chats[selected_chat][-max_history:]

    save_chats(chats)

    # AI Response
    with st.chat_message("assistant"):
        with st.spinner("Thinking... 🤖"):
            reply = get_ai_response(chats[selected_chat])

            st.markdown(reply)

    chats[selected_chat].append({
        "role": "assistant",
        "content": reply,
        "time": now
    })

    save_chats(chats)
    st.rerun()

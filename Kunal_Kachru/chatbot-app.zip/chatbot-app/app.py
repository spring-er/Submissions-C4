import streamlit as st
import requests
import json
import os
import time
from datetime import datetime
from dotenv import load_dotenv

# =====================================================
# CONFIGURATION
# =====================================================

MODEL_NAME = "openai/gpt-oss-120b"
load_dotenv()
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

if not OPENROUTER_API_KEY:
    st.error("❌ OPENROUTER_API_KEY not found in .env file")
    st.stop()

STORAGE_FILE = "storage/chats.json"
os.makedirs("storage", exist_ok=True)

# =====================================================
# STORAGE INITIALIZATION
# =====================================================

if not os.path.exists(STORAGE_FILE):
    with open(STORAGE_FILE, "w") as f:
        json.dump({}, f)

# =====================================================
# STORAGE HELPERS
# =====================================================

def load_chats():
    with open(STORAGE_FILE, "r") as f:
        return json.load(f)

def save_chats(chats):
    with open(STORAGE_FILE, "w") as f:
        json.dump(chats, f, indent=4)

# =====================================================
# CHAT OVERVIEW / PREVIEW
# === ENHANCEMENT: CHAT OVERVIEW IN SIDEBAR ===
# =====================================================

def chat_preview(messages, max_len=40):
    for msg in messages:
        if msg["role"] == "user":
            preview = msg["content"].strip().replace("\n", " ")
            return (preview[:max_len] + "...") if len(preview) > max_len else preview
    return "New conversation"

# =====================================================
# OPENROUTER API CALL
# =====================================================

def get_ai_response(messages):
    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": MODEL_NAME,
        "messages": messages
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code != 200:
        return f"❌ Error: {response.text}"

    return response.json()["choices"][0]["message"]["content"]

# =====================================================
# OPTIONAL CHAT SUMMARY
# =====================================================

def summarize_chat(chat_messages):
    prompt = "Summarize this entire conversation in 2-3 lines."
    summary_messages = chat_messages + [{"role": "user", "content": prompt}]
    return get_ai_response(summary_messages)

# =====================================================
# STREAMLIT PAGE SETUP
# =====================================================

st.set_page_config("Chatbot Assignment", "🤖", layout="wide")
#st.title("💬 Chatbot Style App (OpenRouter + Local Storage)")



# =====================================================
# SESSION TIMER
# =====================================================

if "start_time" not in st.session_state:
    st.session_state.start_time = time.time()

duration = int(time.time() - st.session_state.start_time)

# =====================================================
# LOAD CHAT HISTORY
# === ENHANCEMENT: ENTIRE CHAT HISTORY PER USER ===
# =====================================================

chats = load_chats()

if len(chats) == 0:
    chats["Default Chat"] = []

if "active_chat" not in st.session_state:
    st.session_state.active_chat = list(chats.keys())[0]

# ======================================================
# SIDEBAR CONFIGURATION UI (MATCH SCREENSHOT)
# ======================================================
st.sidebar.title("⚙️ Configuration")

st.sidebar.markdown("## Assistant Settings")

assistant_name = st.sidebar.text_input(
    "Assistant Name:",
    value="This is a cool assistant!"
)

response_style = st.sidebar.selectbox(
    "Response Style:",
    ["Friendly", "Professional", "Funny", "Short"]
)

st.sidebar.markdown("## Chat Settings")

max_history = st.sidebar.slider(
    "Max Chat History:",
    5, 50, 40
)

show_timestamps = st.sidebar.checkbox("Show Timestamps", value=True)

st.sidebar.markdown("---")

# ======================================================
# MAIN CHAT HEADER
# ======================================================
st.markdown(f"# 🚀 {assistant_name}")

st.caption(
    f"Response Style: **{response_style}** | History Limit: **{max_history} messages**"
)

# -----------------------------
# Conversations
# -----------------------------
st.sidebar.markdown("## 💬 Conversations")

chat_names = list(chats.keys())

chat_labels = {
    name: f"{name} — {chat_preview(chats[name])}"
    for name in chat_names
}

selected_label = st.sidebar.selectbox(
    "Select Chat",
    options=list(chat_labels.values()),
    index=list(chat_labels.keys()).index(st.session_state.active_chat)
)

selected_chat = [
    name for name, label in chat_labels.items()
    if label == selected_label
][0]

st.session_state.active_chat = selected_chat

st.sidebar.markdown("---")
# -----------------------------
# Chat Actions
# -----------------------------
st.sidebar.markdown("## 🛠 Chat Actions")

if st.sidebar.button("➕ Create New Chat"):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    new_chat_name = f"Chat {len(chats) + 1} ({timestamp})"

    chats[new_chat_name] = [
        {"role": "system", "content": "This is a new conversation."}
    ]

    save_chats(chats)
    st.session_state.active_chat = new_chat_name
    st.rerun()

if st.sidebar.button("🗑 Delete Selected Chat"):
    if selected_chat in chats:
        del chats[selected_chat]

        if len(chats) == 0:
            chats["Default Chat"] = []

        save_chats(chats)
        st.session_state.active_chat = list(chats.keys())[0]
        st.rerun()

if st.sidebar.button("🧹 Clear Current Chat"):
    chats[selected_chat] = []
    save_chats(chats)
    st.rerun()

st.sidebar.markdown("---")

# -----------------------------
# Export
# -----------------------------
st.sidebar.markdown("## 📦 Export")

def export_chat():
    text = ""
    for msg in chats[selected_chat]:
        text += f"{msg['role'].upper()}: {msg['content']}\n\n"
    return text

def export_all_chats():
    text = ""
    for chat_name, messages in chats.items():
        text += f"===== {chat_name} =====\n\n"
        for msg in messages:
            text += f"{msg['role'].upper()}: {msg['content']}\n\n"
        text += "\n"
    return text

st.sidebar.download_button(
    "📥 Export Current Chat",
    export_chat(),
    file_name=f"{selected_chat}.txt",
    mime="text/plain"
)

st.sidebar.download_button(
    "📦 Export ALL Chats",
    export_all_chats(),
    file_name="all_chat_history.txt",
    mime="text/plain"
)
st.sidebar.markdown("---")
# -----------------------------
# Informational Panels (Expanders)
# -----------------------------
with st.sidebar.expander("📊 Session Stats",True):
    st.markdown(f"""
    - **Session Duration:** {duration} sec  
    - **Total Chats:** {len(chats)}  
    - **Messages in Current Chat:** {len(chats[selected_chat])}
    """)



for msg in chats[selected_chat]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# =====================================================
# CHAT INPUT
# =====================================================

user_input = st.chat_input("Type your message...")

if user_input:
    chats[selected_chat].append({"role": "user", "content": user_input})

    with st.chat_message("user"):
        st.markdown(user_input)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            reply = get_ai_response(chats[selected_chat])
            st.markdown(reply)

    chats[selected_chat].append({"role": "assistant", "content": reply})
    save_chats(chats)
    st.rerun()

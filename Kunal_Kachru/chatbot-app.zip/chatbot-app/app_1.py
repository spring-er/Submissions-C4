import streamlit as st
import requests
import json
import os
import time
from datetime import datetime

# -----------------------------
# CONFIG
# -----------------------------
OPENROUTER_API_KEY = "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"
MODEL_NAME = "openai/gpt-oss-120b"

STORAGE_FILE = "storage/chats.json"

# -----------------------------
# Ensure Storage Exists
# -----------------------------
os.makedirs("storage", exist_ok=True)

if not os.path.exists(STORAGE_FILE):
    with open(STORAGE_FILE, "w") as f:
        json.dump({}, f)

# -----------------------------
# Load Chats from Local Storage
# -----------------------------
def load_chats():
    with open(STORAGE_FILE, "r") as f:
        return json.load(f)

# -----------------------------
# Save Chats to Local Storage
# -----------------------------
def save_chats(chats):
    with open(STORAGE_FILE, "w") as f:
        json.dump(chats, f, indent=4)

# -----------------------------
# OpenRouter API Call
# -----------------------------
def get_ai_response(messages):
    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": MODEL_NAME,
        "messages": messages
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code != 200:
        return f"❌ Error: {response.text}"

    return response.json()["choices"][0]["message"]["content"]

# -----------------------------
# Summarize Chat (Optional)
# -----------------------------
def summarize_chat(chat_messages):
    prompt = "Summarize this entire conversation in 2-3 lines."

    summary_messages = chat_messages + [
        {"role": "user", "content": prompt}
    ]

    return get_ai_response(summary_messages)

# -----------------------------
# Streamlit Page Setup
# -----------------------------
st.set_page_config("Chatbot Assignment", "🤖", layout="wide")
st.title("💬 Chatbot Style App (OpenRouter + Local Storage)")

# -----------------------------
# Session Timer
# -----------------------------
if "start_time" not in st.session_state:
    st.session_state.start_time = time.time()

duration = int(time.time() - st.session_state.start_time)

# -----------------------------
# Load Stored Chats
# -----------------------------
chats = load_chats()

# Default chat if none exist
if len(chats) == 0:
    chats["Default Chat"] = []

# -----------------------------
# Sidebar Chat Manager
# -----------------------------
st.sidebar.title("⚙️ Chat Manager")

chat_names = list(chats.keys())

selected_chat = st.sidebar.selectbox("Select Chat", chat_names)

# Create New Chat
if st.sidebar.button("➕ Create New Chat"):
    new_chat_name = f"Chat {len(chats)+1}"
    chats[new_chat_name] = []
    save_chats(chats)
    st.rerun()

# Delete Chat
if st.sidebar.button("🗑 Delete Selected Chat"):
    if selected_chat in chats:
        del chats[selected_chat]

        # Ensure at least one chat exists
        if len(chats) == 0:
            chats["Default Chat"] = []

        save_chats(chats)
        st.rerun()

# Clear Current Chat
if st.sidebar.button("🧹 Clear Current Chat"):
    chats[selected_chat] = []
    save_chats(chats)
    st.rerun()

# Session Stats
st.sidebar.markdown("### ⏱ Session Duration")
st.sidebar.write(f"**{duration} sec**")

# Export Chat
def export_chat():
    text = ""
    for msg in chats[selected_chat]:
        text += f"{msg['role'].upper()}: {msg['content']}\n\n"
    return text

st.sidebar.download_button(
    "📥 Export Chat (.txt)",
    export_chat(),
    file_name=f"{selected_chat}.txt",
    mime="text/plain"
)

# -----------------------------
# Optional Chat Summary Expander
# -----------------------------
with st.expander("📌 Chat Summary (Optional)"):
    if len(chats[selected_chat]) > 2:
        if st.button("Generate Summary"):
            summary = summarize_chat(chats[selected_chat])
            st.success(summary)
    else:
        st.info("Not enough conversation to summarize.")

# -----------------------------
# Display Chat Messages
# -----------------------------
for msg in chats[selected_chat]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# -----------------------------
# Chat Input
# -----------------------------
user_input = st.chat_input("Type your message...")

if user_input:
    # Add user message
    chats[selected_chat].append({"role": "user", "content": user_input})

    # Show user message
    with st.chat_message("user"):
        st.markdown(user_input)

    # AI Response
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            reply = get_ai_response(chats[selected_chat])
            st.markdown(reply)

    chats[selected_chat].append({"role": "assistant", "content": reply})

    # Save chat to local storage
    save_chats(chats)

    st.rerun()

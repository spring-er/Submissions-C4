import streamlit as st
import requests
import json
import os
import time
from datetime import datetime

# =====================================================
# CONFIGURATION
# =====================================================

# NOTE: In production, this should be stored securely
OPENROUTER_API_KEY = "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"
MODEL_NAME = "openai/gpt-oss-120b"

STORAGE_FILE = "storage/chats.json"

# =====================================================
# STORAGE INITIALIZATION
# =====================================================

os.makedirs("storage", exist_ok=True)

if not os.path.exists(STORAGE_FILE):
    with open(STORAGE_FILE, "w") as f:
        json.dump({}, f)

# =====================================================
# STORAGE HELPERS
# =====================================================

def load_chats():
    with open(STORAGE_FILE, "r") as f:
        return json.load(f)

def save_chats(chats):
    with open(STORAGE_FILE, "w") as f:
        json.dump(chats, f, indent=4)

# =====================================================
# OPENROUTER API CALL
# =====================================================

def get_ai_response(messages):
    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": MODEL_NAME,
        "messages": messages
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code != 200:
        return f"❌ Error: {response.text}"

    return response.json()["choices"][0]["message"]["content"]

# =====================================================
# OPTIONAL CHAT SUMMARY
# =====================================================

def summarize_chat(chat_messages):
    prompt = "Summarize this entire conversation in 2-3 lines."
    summary_messages = chat_messages + [{"role": "user", "content": prompt}]
    return get_ai_response(summary_messages)

# =====================================================
# STREAMLIT PAGE SETUP
# =====================================================

st.set_page_config("Chatbot Assignment", "🤖", layout="wide")
st.title("💬 Chatbot Style App (OpenRouter + Local Storage)")

# =====================================================
# SESSION TIMER
# =====================================================

if "start_time" not in st.session_state:
    st.session_state.start_time = time.time()

duration = int(time.time() - st.session_state.start_time)

# =====================================================
# LOAD CHAT HISTORY
# === ENHANCEMENT: ENTIRE CHAT HISTORY PER USER ===
# =====================================================

chats = load_chats()

if len(chats) == 0:
    chats["Default Chat"] = []

# === ENHANCEMENT: TRACK ACTIVE CHAT IN SESSION STATE ===
if "active_chat" not in st.session_state:
    st.session_state.active_chat = list(chats.keys())[0]

# =====================================================
# SIDEBAR: CHAT MANAGEMENT
# =====================================================

st.sidebar.title("⚙️ Chat Manager")

chat_names = list(chats.keys())

selected_chat = st.sidebar.selectbox(
    "Select Chat",
    chat_names,
    index=chat_names.index(st.session_state.active_chat)
)

st.session_state.active_chat = selected_chat

# =====================================================
# CREATE NEW CHAT
# === ENHANCEMENT: START NEW CHAT WITH CLEAN CONTEXT ===
# =====================================================

if st.sidebar.button("➕ Create New Chat"):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    new_chat_name = f"Chat {len(chats) + 1} ({timestamp})"

    chats[new_chat_name] = [
        {"role": "system", "content": "This is a new conversation."}
    ]

    save_chats(chats)
    st.session_state.active_chat = new_chat_name
    st.rerun()

# =====================================================
# DELETE CHAT
# =====================================================

if st.sidebar.button("🗑 Delete Selected Chat"):
    if selected_chat in chats:
        del chats[selected_chat]

        if len(chats) == 0:
            chats["Default Chat"] = []

        save_chats(chats)
        st.session_state.active_chat = list(chats.keys())[0]
        st.rerun()

# =====================================================
# CLEAR CURRENT CHAT
# =====================================================

if st.sidebar.button("🧹 Clear Current Chat"):
    chats[selected_chat] = []
    save_chats(chats)
    st.rerun()

# =====================================================
# SESSION STATS
# =====================================================

st.sidebar.markdown("### ⏱ Session Duration")
st.sidebar.write(f"**{duration} sec**")

# =====================================================
# EXPORT FUNCTIONS
# =====================================================

def export_chat():
    text = ""
    for msg in chats[selected_chat]:
        text += f"{msg['role'].upper()}: {msg['content']}\n\n"
    return text

# === ENHANCEMENT: EXPORT ENTIRE CHAT HISTORY ===
def export_all_chats():
    text = ""
    for chat_name, messages in chats.items():
        text += f"===== {chat_name} =====\n\n"
        for msg in messages:
            text += f"{msg['role'].upper()}: {msg['content']}\n\n"
        text += "\n"
    return text

st.sidebar.download_button(
    "📥 Export Current Chat (.txt)",
    export_chat(),
    file_name=f"{selected_chat}.txt",
    mime="text/plain"
)

st.sidebar.download_button(
    "📦 Export ALL Chats (.txt)",
    export_all_chats(),
    file_name="all_chat_history.txt",
    mime="text/plain"
)

# =====================================================
# OPTIONAL CHAT SUMMARY
# =====================================================

with st.expander("📌 Chat Summary (Optional)"):
    if len(chats[selected_chat]) > 2:
        if st.button("Generate Summary"):
            summary = summarize_chat(chats[selected_chat])
            st.success(summary)
    else:
        st.info("Not enough conversation to summarize.")

# =====================================================
# DISPLAY CHAT MESSAGES
# =====================================================

for msg in chats[selected_chat]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# =====================================================
# CHAT INPUT
# =====================================================

user_input = st.chat_input("Type your message...")

if user_input:
    chats[selected_chat].append({"role": "user", "content": user_input})

    with st.chat_message("user"):
        st.markdown(user_input)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            reply = get_ai_response(chats[selected_chat])
            st.markdown(reply)

    chats[selected_chat].append({"role": "assistant", "content": reply})
    save_chats(chats)
    st.rerun()


import React from 'react';
import ThemeToggle from './ThemeToggle';
import LinkedinIcon from './icons/LinkedinIcon';

interface HeaderProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const Header: React.FC<HeaderProps> = ({ theme, toggleTheme }) => {
  return (
    <header className="p-4 bg-white dark:bg-gray-800 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center gap-2">
          <LinkedinIcon className="h-8 w-8 text-[#0A66C2]" />
          <h1 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white">
            AutoLinkedIn
          </h1>
        </div>
        <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
      </div>
    </header>
  );
};

export default Header;

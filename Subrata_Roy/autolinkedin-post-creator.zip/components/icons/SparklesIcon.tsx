
import React from 'react';

const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M12 2L9 9l-7 3 7 3 3 7 3-7 7-3-7-3-3-7z" />
    <path d="M22 12l-3 1.5L16 12l1.5-3L16 6l3 1.5L22 6l-1.5 3L22 12z" />
    <path d="M8 22l1.5-3L8 16l-1.5 3L8 22z" />
    <path d="M12 22l3-1.5L18 22l-1.5-3L18 16l-3 1.5L12 16l1.5 3L12 22z" />
  </svg>
);

export default SparklesIcon;


import React from 'react';
import LinkedinIcon from './icons/LinkedinIcon';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <div className="container mx-auto px-4 py-24 flex flex-col items-center justify-center text-center">
      <div className="relative mb-8">
        <LinkedinIcon className="h-24 w-24 text-[#0A66C2]" />
        <span className="absolute top-0 right-0 -mr-4 -mt-2 animate-pulse">
            <svg className="w-8 h-8 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 15a1 1 0 01-1-1v- законодательство-related-icon-path...M10 15a1 1 0 01-1-1V5a1 1 0 112 0v9a1 1 0 01-1 1zm0 2a8 8 0 100-16 8 8 0 000 16zM5.293 6.707a1 1 0 011.414-1.414L10 8.586l3.293-3.293a1 1 0 111.414 1.414L11.414 10l3.293 3.293a1 1 0 01-1.414 1.414L10 11.414l-3.293 3.293a1 1 0 01-1.414-1.414L8.586 10 5.293 6.707z" clipRule="evenodd" fillRule="evenodd" />
            </svg>
        </span>
      </div>
      <h2 className="text-4xl md:text-6xl font-extrabold text-gray-900 dark:text-white mb-4">
        Craft Perfect LinkedIn Posts in Seconds
      </h2>
      <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 max-w-2xl mb-8">
        Leverage the power of AI to generate engaging, professional content tailored for your audience. Save time, boost your presence, and make an impact.
      </p>
      <button
        onClick={onStart}
        className="px-8 py-4 bg-[#0A66C2] text-white font-bold text-lg rounded-full hover:bg-[#004182] transition-transform transform hover:scale-105 duration-300 shadow-lg"
      >
        Start for Free
      </button>
    </div>
  );
};

export default LandingPage;

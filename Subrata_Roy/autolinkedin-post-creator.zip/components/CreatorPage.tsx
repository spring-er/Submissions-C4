
import React, { useState, useCallback } from 'react';
import { WritingStyle, PostCategory, PostLength, PostOptions } from '../types';
import { generatePost } from '../services/geminiService';
import { sendDataToWebhook, postContentToWebhook } from '../services/webhookService';
import SparklesIcon from './icons/SparklesIcon';

const CreatorPage: React.FC = () => {
  const [options, setOptions] = useState<PostOptions>({
    topic: '',
    writingStyle: WritingStyle.PROFESSIONAL,
    postCategory: PostCategory.THOUGHT_LEADERSHIP,
    length: PostLength.MEDIUM,
  });
  const [generatedPost, setGeneratedPost] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isPosted, setIsPosted] = useState<boolean>(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setOptions(prev => ({ ...prev, [name]: value as any }));
  };

  const lengthOptions = Object.values(PostLength);
  const sliderValue = lengthOptions.indexOf(options.length);
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newLength = lengthOptions[parseInt(e.target.value, 10)];
    setOptions(prev => ({ ...prev, length: newLength }));
  };

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!options.topic.trim()) {
      setError('Please enter a topic.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedPost('');
    setIsPosted(false); // Reset posting status on new generation

    try {
      // Fire-and-forget webhook call for generation analytics
      sendDataToWebhook(options).catch(console.error);
      
      const post = await generatePost(options);
      setGeneratedPost(post);
    } catch (err) {
      console.error(err);
      setError('Failed to generate post. Please check your API key and try again.');
    } finally {
      setIsLoading(false);
    }
  }, [options]);
  
  const handlePost = () => {
    // Fire-and-forget webhook call with the final post content
    postContentToWebhook(generatedPost).catch(console.error);

    setIsPosted(true);
    setTimeout(() => {
        setIsPosted(false); // Reset after 3 seconds
    }, 3000);
  };

  const handleOutputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setGeneratedPost(e.target.value);
    if(isPosted) {
        setIsPosted(false); // If user edits, reset posted state
    }
  };

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form Section */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold mb-6 text-[#0A66C2] dark:text-blue-400">Create Your Post</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="topic" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Enter Main Topic</label>
              <input
                type="text"
                id="topic"
                name="topic"
                value={options.topic}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-[#0A66C2] focus:border-[#0A66C2] bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white"
                placeholder="e.g., The future of remote work"
                required
              />
            </div>

            <div>
              <label htmlFor="writingStyle" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Select Writing Style</label>
              <select id="writingStyle" name="writingStyle" value={options.writingStyle} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-[#0A66C2] focus:border-[#0A66C2] bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white" required>
                {Object.values(WritingStyle).map(style => <option key={style} value={style}>{style}</option>)}
              </select>
            </div>

            <div>
              <label htmlFor="postCategory" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Select Post Category</label>
              <select id="postCategory" name="postCategory" value={options.postCategory} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-[#0A66C2] focus:border-[#0A66C2] bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white" required>
                {Object.values(PostCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
            </div>

            <div>
              <label htmlFor="length" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Select Post Length</label>
                <div className="flex items-center gap-4 pt-2">
                    <input
                        type="range"
                        id="length"
                        name="length"
                        min="0"
                        max={lengthOptions.length - 1}
                        step="1"
                        value={sliderValue}
                        onChange={handleSliderChange}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                        required
                    />
                    <span className="font-semibold text-gray-800 dark:text-gray-200 w-24 text-center">{options.length}</span>
                </div>
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 px-1 mt-1">
                    <span>Min: Short</span>
                    <span>Mid: Medium</span>
                    <span>Max: Long</span>
                </div>
            </div>

            <button type="submit" disabled={isLoading} className="w-full flex justify-center items-center gap-2 px-4 py-3 bg-[#0A66C2] text-white font-bold rounded-md hover:bg-[#004182] transition duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed">
              {isLoading ? 'Generating...' : 'Generate Post'}
              {!isLoading && <SparklesIcon className="h-5 w-5" />}
            </button>
          </form>
        </div>

        {/* Output Section */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col">
          <h2 className="text-2xl font-bold mb-4 text-[#0A66C2] dark:text-blue-400">Generated Post</h2>
          <div className="flex-grow bg-gray-100 dark:bg-gray-900 rounded-md p-4 min-h-[300px] overflow-y-auto">
            {isLoading && (
              <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-[#0A66C2]"></div>
              </div>
            )}
            {error && <p className="text-red-500">{error}</p>}
            {!isLoading && !error && (
              <textarea
                className="w-full h-full bg-transparent border-0 resize-none focus:ring-0 text-gray-800 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400"
                value={generatedPost}
                onChange={handleOutputChange}
                placeholder="Your generated post will appear here."
                aria-label="Generated post output"
              />
            )}
          </div>
          {generatedPost && !isLoading && (
            <div className="mt-4">
              <button 
                onClick={handlePost} 
                disabled={isPosted}
                className={`w-full px-4 py-2 text-white font-bold rounded-md transition-colors duration-300 disabled:cursor-not-allowed ${
                    isPosted 
                    ? 'bg-green-600 hover:bg-green-700 disabled:bg-green-500' 
                    : 'bg-[#0A66C2] hover:bg-[#004182]'
                }`}
              >
                {isPosted ? 'Posted ✔' : 'Post to LinkedIn'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreatorPage;

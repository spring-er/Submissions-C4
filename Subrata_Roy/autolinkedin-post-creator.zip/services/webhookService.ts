
import { PostOptions } from '../types';

const WEBHOOK_URL = 'https://subrata80online.app.n8n.cloud/webhook-test/f75e2841-2e32-4487-9922-4996d39e8d4e';
const POST_CONTENT_WEBHOOK_URL = 'https://subrata80online.app.n8n.cloud/webhook-test/78347d21-8eb6-4727-8919-d9562c88875d';


export const sendDataToWebhook = async (options: PostOptions): Promise<void> => {
  const payload = {
    topic: options.topic,
    writing_style: options.writingStyle,
    post_category: options.postCategory,
    post_length: options.length,
  };

  try {
    const response = await fetch(WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      // We don't throw an error to block the user, but we log it.
      console.error(`Webhook call failed with status: ${response.status}`);
      const responseBody = await response.text();
      console.error('Webhook response:', responseBody);
    } else {
      console.log('Data successfully sent to webhook.');
    }
  } catch (error) {
    console.error('An error occurred while sending data to the webhook:', error);
  }
};

export const postContentToWebhook = async (postContent: string): Promise<void> => {
  try {
      const response = await fetch(POST_CONTENT_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ postContent }),
      });

      if (!response.ok) {
          console.error(`Post content webhook call failed: ${response.status}`);
          const responseBody = await response.text();
          console.error('Post content webhook response:', responseBody);
      } else {
          console.log('Content successfully sent to post webhook.');
      }
  } catch (error) {
      console.error('An error occurred while sending content to the post webhook:', error);
  }
};

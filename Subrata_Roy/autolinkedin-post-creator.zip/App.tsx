
import React, { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import CreatorPage from './components/CreatorPage';
import Header from './components/Header';

type Theme = 'light' | 'dark';
type View = 'landing' | 'creator';

const App: React.FC = () => {
  const [theme, setTheme] = useState<Theme>(() => {
    // Default to light theme, unless user has a preference saved
    return (localStorage.getItem('theme') as Theme) || 'light';
  });
  const [view, setView] = useState<View>('landing');

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
  };

  const startCreating = () => {
    setView('creator');
  };

  return (
    <div className="min-h-screen text-gray-800 dark:text-gray-200 transition-colors duration-300">
      <Header theme={theme} toggleTheme={toggleTheme} />
      <main>
        {view === 'landing' && <LandingPage onStart={startCreating} />}
        {view === 'creator' && <CreatorPage />}
      </main>
    </div>
  );
};

export default App;

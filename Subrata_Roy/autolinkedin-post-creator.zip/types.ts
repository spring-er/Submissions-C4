
export enum WritingStyle {
  PROFESSIONAL = "Professional",
  INSPIRATIONAL = "Inspirational",
  EDUCATIONAL = "Educational",
  STORYTELLING = "Storytelling",
  CONVERSATIONAL = "Conversational",
  PROMOTIONAL = "Promotional",
}

export enum PostCategory {
  THOUGHT_LEADERSHIP = "Thought Leadership",
  PERSONAL_STORY = "Personal Story",
  INDUSTRY_INSIGHT = "Industry Insight",
  CASE_STUDY = "Case Study",
  ANNOUNCEMENT = "Announcement",
  HOW_TO_TIPS = "How-To / Tips",
  CAREER_ADVICE = "Career Advice",
}

export enum PostLength {
  SHORT = 'Short',
  MEDIUM = 'Medium',
  LONG = 'Long'
}

export interface PostOptions {
  topic: string;
  writingStyle: WritingStyle;
  postCategory: PostCategory;
  length: PostLength;
}

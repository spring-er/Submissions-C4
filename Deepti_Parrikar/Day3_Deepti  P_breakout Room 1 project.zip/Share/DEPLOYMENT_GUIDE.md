# Deploying to Hugging Face Spaces

Follow these steps to deploy your chatbot to the web.

## 1. Create a Space
1.  Go to [huggingface.co/spaces](https://huggingface.co/spaces) (Log in or Sign up).
2.  Click **"Create new Space"**.
3.  **Space Name**: Enter a name (e.g., `my-chatbot`).
4.  **License**: Optional (MIT is common).
5.  **SDK**: Select **Docker** (since you chose this, we added a Dockerfile).
6.  **Template**: Select **Blank**.
7.  **Visibility**: Public or Private.
8.  Click **"Create Space"**.

## 2. Configure Secrets
Your app needs the `OPENROUTER_API_KEY` to function. We cannot upload this securely in the code.
1.  In your new Space, verify you are on the **Settings** tab.
2.  Scroll down to the **Variables and secrets** section.
3.  Click **"New secret"**.
    - **Name**: `OPENROUTER_API_KEY`
    - **Value**: (Paste your actual API key here)
4.  Click **Save**.

## 3. Push Your Code
You need to push your local code to the Hugging Face git repository.

### Option A: Via Command Line (Recommended)
Run the following commands in your terminal (inside the `outsillE` folder):

```bash
# 1. Add the Hugging Face remote (replace USER/SPACE_NAME with your actual details)
git remote add space https://huggingface.co/spaces/YOUR_USERNAME/YOUR_SPACE_NAME

# 2. Push your code
git push space master:main
```
*Note: You may be asked for your Hugging Face username and password. If you have 2FA enabled, use an Access Token explicitly.*

### Option B: Via Web Upload
1.  Go to the **Files** tab of your Space.
2.  Click **"Add file"** > **"Upload files"**.
3.  Drag and drop the following files from your `outsillE` folder:
    - `app.py`
    - `chat_utils.py`
    - `requirements.txt`
    - `.gitignore` (optional)
4.  Click **"Commit changes to main"**.

## 4. Verification
- Go to the **App** tab in your Space.
- Wait for the "Building" status to finish.
- Once running, try chatting!

import json
import os
import streamlit as st
from openai import OpenAI
from datetime import datetime
import glob

# Directory to store chat files
CHATS_DIR = "chats"
CHAT_HISTORY_FILE = "chat_history.json" # Legacy file

def get_openai_client():
    """Configures and returns the OpenAI client for OpenRouter."""
    # Try getting from environment variable first (standard for Docker/HF Spaces)
    api_key = os.environ.get("OPENROUTER_API_KEY")
    
    # Fallback to streamlit secrets (local development)
    if not api_key:
        try:
            api_key = st.secrets.get("OPENROUTER_API_KEY")
        except FileNotFoundError:
            pass # No secrets file found
            
    if not api_key:
        st.error("OpenRouter API Key not found. Please set OPENROUTER_API_KEY in Environment Variables or .streamlit/secrets.toml")
        return None
    
    return OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=api_key
    )

def migrate_legacy_history():
    """Migrates monolithic chat_history.json to individual files in chats/."""
    if not os.path.exists(CHATS_DIR):
        os.makedirs(CHATS_DIR)

    if os.path.exists(CHAT_HISTORY_FILE):
        try:
            with open(CHAT_HISTORY_FILE, "r") as f:
                data = json.load(f)
            
            for chat_id, content in data.items():
                # Normalize legacy format if needed (should already be somewhat standard from previous step, but be safe)
                if isinstance(content, list):
                    chat_data = {
                        "created_at": datetime.now().isoformat(),
                        "messages": content
                    }
                else:
                    chat_data = content
                
                # Save to new location
                save_chat(chat_id, chat_data)
            
            # Rename legacy file to backup
            os.rename(CHAT_HISTORY_FILE, f"{CHAT_HISTORY_FILE}.bak")
            print(f"Migrated {len(data)} chats to {CHATS_DIR}/")
            
        except json.JSONDecodeError:
            print("Error reading legacy chat history file.")
        except Exception as e:
            print(f"Migration error: {e}")

def load_chat_history():
    """Loads all chat histories from the chats/ directory."""
    # Ensure directory exists
    if not os.path.exists(CHATS_DIR):
        os.makedirs(CHATS_DIR)
        
    # Check for legacy file and migrate if present
    if os.path.exists(CHAT_HISTORY_FILE):
        migrate_legacy_history()

    all_chats = {}
    chat_files = glob.glob(os.path.join(CHATS_DIR, "*.json"))
    
    for file_path in chat_files:
        try:
            filename = os.path.basename(file_path)
            chat_id = os.path.splitext(filename)[0]
            
            with open(file_path, "r") as f:
                chat_data = json.load(f)
                all_chats[chat_id] = chat_data
        except Exception as e:
            print(f"Error loading chat {file_path}: {e}")
            
    return all_chats

def save_chat(chat_id, chat_data):
    """Saves a specific chat to its own JSON file."""
    if not os.path.exists(CHATS_DIR):
        os.makedirs(CHATS_DIR)
        
    file_path = os.path.join(CHATS_DIR, f"{chat_id}.json")
    with open(file_path, "w") as f:
        json.dump(chat_data, f, indent=4)

def delete_chat(chat_id):
    """Deletes a specific chat session file."""
    file_path = os.path.join(CHATS_DIR, f"{chat_id}.json")
    if os.path.exists(file_path):
        os.remove(file_path)
        return True
    return False

def get_chat_response(messages, model="openai/gpt-oss-120b"):
    """Sends messages to the LLM and returns the response content."""
    client = get_openai_client()
    if not client:
        return "Error: API Client not configured."

    try:
        # Strip internal keys like 'timestamp' before sending to API if necessary
        api_messages = [{"role": m["role"], "content": m["content"]} for m in messages]

        completion = client.chat.completions.create(
            extra_headers={
                "HTTP-Referer": "https://localhost:8501", # Optional: for OpenRouter rankings
                "X-Title": "Streamlit Chatbot", # Optional: for OpenRouter rankings
            },
            model=model,
            messages=api_messages
        )
        return completion.choices[0].message.content
    except Exception as e:
        return f"Error communicating with API: {str(e)}"
